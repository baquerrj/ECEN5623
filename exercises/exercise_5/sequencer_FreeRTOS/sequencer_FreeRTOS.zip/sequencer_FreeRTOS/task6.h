/*
 * task6.h
 *
 *  Created on: Apr 3, 2020
 *      Author: baquerrj
 */

#ifndef TASK6_H_
#define TASK6_H_


extern uint32_t TaskSixInit( void );



#endif /* TASK6_H_ */
