/*
 * taskOne.h
 *
 *  Created on: Mar 15, 2020
 *      Author: baquerrj
 */

#ifndef TASKONE_H
#define TASKONE_H

extern uint32_t TaskOneInit( void );

#endif /* TASKONE_H */
