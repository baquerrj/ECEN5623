/*
 * task5.h
 *
 *  Created on: Apr 3, 2020
 *      Author: baquerrj
 */

#ifndef TASK5_H_
#define TASK5_H_

extern uint32_t TaskFiveInit( void );




#endif /* TASK5_H_ */
