/*
 * task7.h
 *
 *  Created on: Apr 3, 2020
 *      Author: baquerrj
 */

#ifndef TASK7_H_
#define TASK7_H_


extern uint32_t TaskSevenInit( void );



#endif /* TASK7_H_ */
