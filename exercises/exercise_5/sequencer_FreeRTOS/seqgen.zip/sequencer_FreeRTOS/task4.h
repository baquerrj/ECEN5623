/*
 * task4.h
 *
 *  Created on: Apr 3, 2020
 *      Author: baquerrj
 */

#ifndef TASK4_H_
#define TASK4_H_


extern uint32_t TaskFourInit( void );



#endif /* TASK4_H_ */
