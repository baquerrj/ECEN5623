/*
 * taskTwo.h
 *
 *  Created on: Mar 15, 2020
 *      Author: baquerrj
 */

#ifndef TASKTWO_H
#define TASKTWO_H

extern uint32_t TaskTwoInit( void );

#endif /* TASKTWO_H */
