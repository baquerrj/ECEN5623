/*
 * processingTask.h
 *
 *  Created on: Mar 15, 2020
 *      Author: baquerrj
 */

#ifndef PROCESSINGTASK_H_
#define PROCESSINGTASK_H_

extern uint32_t ProcessingTaskInit( void );

#endif /* PROCESSINGTASK_H_ */
